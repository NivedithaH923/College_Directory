package com.oct.college_directory.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oct.college_directory.entity.*;
import com.oct.college_directory.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	private final UserService userService;

	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}
	@GetMapping
	public List<Users> findAllUser(){
		return userService.findAllUser();
		
	}
	@GetMapping("/{id}")
	public Optional<Users> findUser(@PathVariable("id") Long id){
		return userService.findById(id);
	}
	
	@PostMapping
	public Users saveUser(@RequestBody Users user) {
		return userService.saveUser(user);
	}
	@PutMapping
	public Users updateUser(@RequestBody Users user) {
		return userService.updateUser(user);
	}
	@DeleteMapping
	public void deleteUser(@PathVariable("id") Long id) {
		userService.deleteUser(id);
		
	}
}
