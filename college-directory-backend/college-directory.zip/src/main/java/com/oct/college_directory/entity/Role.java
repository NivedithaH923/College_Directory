package com.oct.college_directory.entity;

public enum Role {
	STUDENT,
    FACULTY_MEMBER,
    ADMINISTRATOR

}
